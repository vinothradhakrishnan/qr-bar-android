<?php
$config['map-api-key'] = 		'AIzaSyDXGwTpBuTxCzfS3O8D-GDRCS90OA-Szvs';
$config['youtube-api-key'] = 	'AIzaSyDXGwTpBuTxCzfS3O8D-GDRCS90OA-Szvs';

$config['show-google-ads'] = false;
$config['google-data-ad-client'] = 'pub-2911253224693209';


$config['google-ad-width'] = '600px';
$config['google-ad-height'] = '70px';
?>

<script type="text/javascript">
	
	var config = {ad_width: '<?php echo $config['google-ad-width'];?>',
				  ad_height: '<?php echo $config['google-ad-height'];?>',
				  ad_client_id: '<?php echo $config['google-data-ad-client'];?>',
				  show_ads: <?php echo $config['show-google-ads'] ? 'true' : 'false';?>};
</script>