$(document).ready(function() {
        // $('ul.pagination li').click(function(e) 
        // { 
        //     alert($(this).html());
        // });
});